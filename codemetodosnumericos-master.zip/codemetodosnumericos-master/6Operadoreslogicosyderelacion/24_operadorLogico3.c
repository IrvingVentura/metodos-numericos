#include <stdio.h>
#include <stdlib.h>

int main(){
    printf(" %d\n",3>5);
    printf(" %d\n",3<5);
    printf(" %d\n",3==5);
    printf(" %d\n",3!=5);

    printf("\n");
    return 0;
}