#include <stdio.h>
#include <stdlib.h>

int main()
{
    int c = 5;
    printf("c : %d\n", c);
    printf("c++ : %d\n",c++);
    printf("c : %d\n", c);

    int d = 10;
    printf("d : %d\n", d);
    printf("--d : %d\n", --d);
    printf("d : %d\n", d);

    printf("\n");
    return 0;
}