#include <stdio.h>
#include <stdlib.h>

int main(){
    int var = 1;
    int con = 1;
    printf("%d\n",var++);
    printf("%d\n",var);

    printf("%d\n",con--);
    printf("%d\n",con);

    printf("\n");
    return 0;
}