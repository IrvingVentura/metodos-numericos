#include <stdio.h>
#include <stdlib.h>

int main(){
    int unNumero = 3;
    int otroNumero = 4;
    //Quiero imprimir la suma de 3 mas 4
    printf("%d", unNumero+otroNumero);
    
    printf("\n");
    return 0;
}