#include <stdio.h>
#include <stdlib.h>

int main()
{
    double var1 = 29.0;
    double var2 = 4.0;
    printf("El resultado de dividir %f/%f es = %f", var1, var1, var1 / var2);
    printf("\n");
    return 0;
}