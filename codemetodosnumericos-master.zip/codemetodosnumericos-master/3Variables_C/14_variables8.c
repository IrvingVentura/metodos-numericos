#include <stdio.h>
#include <stdlib.h>

int main()
{
    double d = 10;
    double r = d / 2;
    double pi = 3.1416;
    double area = pi * r * r;
    printf("%f", area);

    printf("\n");
    return 0;
}