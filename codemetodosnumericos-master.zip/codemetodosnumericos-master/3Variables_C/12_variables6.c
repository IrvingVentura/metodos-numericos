#include <stdio.h>
#include <stdlib.h>

int main(){
    int a=27;
    int b = 10;
    int c = 18;
    printf("el resultado de %d * %d * %d es = %d",a,b,c,a*b*c);

    printf("\n");
    return 0;
}