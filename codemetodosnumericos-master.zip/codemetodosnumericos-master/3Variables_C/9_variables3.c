#include <stdio.h>
#include <stdlib.h>

int main()
{
    double r = 5;
    double pi = 3.1416;
    double area = pi * r * r;
    printf("%f", area);

    printf("\n");
    return 0;
}