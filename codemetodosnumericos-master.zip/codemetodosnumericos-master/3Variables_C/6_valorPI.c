#include <stdio.h>
#include <stdlib.h>
#define PI 3.1415926

int main(){
    printf("Pi vale %f\n",PI);
    printf("\n");
    return 0;
}