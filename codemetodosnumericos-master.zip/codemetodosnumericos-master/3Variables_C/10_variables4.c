#include <stdio.h>
#include <stdlib.h>

int main(){
    double a = 3.1;
    double A = 4.5;
    printf("%f",a+A);

    printf("\n");
    return 0;
}