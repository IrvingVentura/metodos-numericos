#include <stdio.h>
#include <stdlib.h>

int main()
{
    int una_variable;
    una_variable = 3;
    una_variable = una_variable + 5;
    una_variable++;
    printf("%d", una_variable);
    printf("\n");
    return 0;
}