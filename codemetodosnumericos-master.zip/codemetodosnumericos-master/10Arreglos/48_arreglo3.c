#include <stdio.h>
#include <stdlib.h>

int main(){
    int vector[10];
    int i= 0;
    while (i<10)
    {
        vector[i] = 10;
        printf("%d\n",vector[i]);
        i++;

    }

    system("Pause");
    return 0;
}