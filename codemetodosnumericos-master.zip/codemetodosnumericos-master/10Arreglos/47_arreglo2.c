#include <stdio.h>
#include <stdlib.h>

int main(){
    int vector[10];

    vector[0] = 10;
    vector[1] = 10;
    vector[2] = 10;
    vector[3] = 10;
    vector[4] = 10;
    vector[5] = 10;
    vector[6] = 10;
    vector[7] = 10;
    vector[8] = 10;
    vector[9] = 10;

    printf("%d\n",vector[0]);
    printf("%d\n",vector[1]);
    printf("%d\n",vector[2]);
    printf("%d\n",vector[3]);
    printf("%d\n",vector[4]);
    printf("%d\n",vector[5]);
    printf("%d\n",vector[6]);
    printf("%d\n",vector[7]);
    printf("%d\n",vector[8]);
    printf("%d\n",vector[9]);
    
    system("Pause");
    return 0;
}