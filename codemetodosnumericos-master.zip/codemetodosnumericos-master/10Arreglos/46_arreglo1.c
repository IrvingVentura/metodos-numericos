#include <stdio.h>

int main()
{
    int miArreglo[8];
    miArreglo[0] = 5;
    miArreglo[1] = 10;
    miArreglo[2] = miArreglo[0] + miArreglo[1];
    system("Pause");
    return 0;
}