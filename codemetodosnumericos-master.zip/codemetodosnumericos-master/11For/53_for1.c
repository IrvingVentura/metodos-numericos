#include <stdio.h>

int main()
{
    int vector[10];
    int i = 0;
    for (i = 0; i < 10; i++)
    {
        vector[i] = 10;
    }
}