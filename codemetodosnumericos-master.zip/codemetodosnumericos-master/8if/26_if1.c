#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    if (true)
    {
        printf("Todo este ");
        printf("código, se imprime dentro ");
        printf("del bloque if ");
    }
    printf("\n");
    return 0;
}