#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero = 135;
    if (numero < 100)
    {
        printf("El numero es menor que 100");
        if (numero > 50)
        {
            printf(" y mayor que 50\n");
        }
    }

    printf("\n");
    return 0;
}
