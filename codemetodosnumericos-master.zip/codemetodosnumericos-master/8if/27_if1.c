#include <stdio.h>
#include <stdlib.h>

int main(){
    int numero =34;
    if (numero%2==0)
    {
        printf("El numero es par\n");
    }
    printf("Fin del programa\n");
    

    printf("\n");
    return 0;
}