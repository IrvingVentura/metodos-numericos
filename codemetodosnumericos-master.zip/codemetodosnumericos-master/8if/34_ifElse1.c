#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero = 36;
    if (numero < 50)
    {
        printf("El numero es menor que 50\n");
    }
    else
    {
        printf("El numero es mayor que 50\n");
    }

    printf("Fin del programa\n");
    printf("\n");
    return 0;
}