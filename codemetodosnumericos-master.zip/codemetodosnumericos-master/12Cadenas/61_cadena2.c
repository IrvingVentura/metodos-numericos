#include <stdio.h>

int main()
{
    char cad[] = "Es una cadena";
    printf("%s \n", cad);
    system("Pause");
    return 0;
}