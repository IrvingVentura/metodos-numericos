#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int len;
    char origen[] = "brisas";
    char destino[20] = "para";
    strcat(destino, origen);
    printf("destino: %s", destino);

    printf("\n");
    return 0;
}