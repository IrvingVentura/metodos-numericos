#include <stdio.h>
#include <stdlib.h>

int main()
{
    char cad[10];
    int i;
    printf("Introduce una palabara:\n");
    scanf("%s", cad);
    printf("%s", cad);
    printf("\n");
    return 0;
}