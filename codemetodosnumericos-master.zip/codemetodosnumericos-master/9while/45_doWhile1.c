#include <stdio.h>
#include <stdlib.h>

int main ()
{
    int i = 0;
    do
    {
        printf("Valor de i = %d\n", 1);
        i++;
    } while (i < 3);
    printf("fin");
    printf("\n");
    system("Pause");
}