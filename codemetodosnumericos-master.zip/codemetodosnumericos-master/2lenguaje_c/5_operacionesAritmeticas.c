#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("El resultado de sumar %d + %d es = %d\n", 5, 8, 5 + 8);
    printf("El resultado de sumar %d + %d es = %d\n", 78787, 3259, 78787 + 3259);
    printf("\n");
    return 0;
}