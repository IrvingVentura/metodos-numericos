#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Este es un texto \n");
    printf("que fue impreso desde C");
    printf("\n");
    printf("Ya soy todo un programador");
    printf("\n");
    system("pause");
    return 0;
}