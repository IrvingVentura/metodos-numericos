#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Quiero imprimir el numero 3
    printf("%d\n", 3);
    // Quiero imprimir la suma de 3 mas 4
    printf("%d\n", 3 + 4);
    printf("La suma de %d + %d es = %d\n", 3, 4, 3 + 4);
    system("Pause");
    return 0;
}
