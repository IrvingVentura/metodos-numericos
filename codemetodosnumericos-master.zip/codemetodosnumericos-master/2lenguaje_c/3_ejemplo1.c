#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Bienvenido Jorge, \n es un gusto programar para Jorge");
    printf("\n");
    return 0;
}