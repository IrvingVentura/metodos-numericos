#include <stdio.h>
#include <stdlib.h>

int main()
{
    int p = 5;
    int q = 1;
    int r = 2;
    int w = 3;
    int x = 9;
    int y = 6;
    int z;
    z = p * r % q + w / x - y;
    printf("z : %d\n", z);

    printf("\n");
    return 0;
}