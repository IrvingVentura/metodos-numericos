#include <stdio.h>
#include <stdlib.h>

int main(){
    printf("1 + 2 * 3 : %d\n",1+2*3);
    printf("(1 + 2) * 3 : %d\n",(1+2)*3);
    printf("1 + (2 * 3) :%d",1+(2*3));

    printf("\n");
    return 0;
}