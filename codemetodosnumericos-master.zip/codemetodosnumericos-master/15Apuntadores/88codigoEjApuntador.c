#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    printf("Ingresa un numero: ");
    scanf("%d", &a);
    printf("El valor de 'a' es: %d",&a);


    printf("\n");
    return 0;
}